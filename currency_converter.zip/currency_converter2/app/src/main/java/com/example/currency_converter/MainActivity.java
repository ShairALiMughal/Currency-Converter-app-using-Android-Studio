package com.example.currency_converter;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    EditText currency;
    Button lgn_btn;
    TextView answer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        currency = findViewById(R.id.currency);
        answer = findViewById(R.id.answer);


        lgn_btn = findViewById(R.id.lgn_btn);

        lgn_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (currency.getText().toString().isEmpty())
                    Toast.makeText(getApplicationContext(), "Enter ammount Please..", Toast.LENGTH_SHORT).show();
                else {
                    double ans = Double.parseDouble(currency.getText().toString());

                    hideKeybaord(view);

                    RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.CONTEXT_INCLUDE_CODE);

                    JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, "http://api.exchangeratesapi.io/v1/latest?access_key=5bfe18eebba3f21f71207b94c7eb80b8", null, new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                answer.setText(" "+ response.getString("base") +" $");
                                Log.d("myspp","the reponse is " + response.getString("base"));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                        Log.d("myapp", "the response fail");
                        }
                    });
                    requestQueue.add(jsonObjectRequest);
                }
            }

        });

    }

    private void hideKeybaord(View v) {
        InputMethodManager inputMethodManager = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(v.getApplicationWindowToken(),0);
    }




}
